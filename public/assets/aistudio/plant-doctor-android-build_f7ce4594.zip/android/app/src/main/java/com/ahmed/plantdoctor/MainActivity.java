package com.ahmed.plantdoctor;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
