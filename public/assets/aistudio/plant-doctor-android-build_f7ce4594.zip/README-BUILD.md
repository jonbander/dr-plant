# طبيب الأوراق — بنية البناء الكاملة (Capacitor + Android)

هذا المشروع هو بنية إنتاج التطبيق (APK) لتطبيق «طبيب الأوراق» — تشخيص أمراض النبات من صورة الورقة.
النسخة الحالية: **v1.2** | معرّف التطبيق: `com.ahmed.plantdoctor` | المطوّر: أحمد

## محتويات المشروع

```
├── www/index.html              ← التطبيق كاملاً (ملف واحد، 81KB، بلا اعتماديات)
├── capacitor.config.json       ← إعدادات Capacitor
├── package.json                ← اعتماديات Node
├── keystore/plant-doctor.jks   ← مفتاح التوقيع الثابت (مهم جداً — لا تحذفه!)
└── android/                    ← مشروع أندرويد الأصلي
    ├── app/build.gradle        ← يحوي versionCode/versionName وتوقيع release
    └── app/src/main/
        ├── AndroidManifest.xml ← أذونات الكاميرا والوسائط
        ├── java/…/MainActivity.java
        └── res/                ← الأيقونات (mipmap) وشاشات البداية (splash)
```

## إعادة البناء من الصفر (على أي جهاز تطوير)

المتطلبات: JDK 17+ (نُسخنا بـ 21)، Android SDK (platform 35 أو أحدث + build-tools 35)، Node 18+.

```bash
# 1) تثبيت اعتماديات Node
npm install

# 2) مزامنة أصول الويب (www → android)
npx cap sync android

# 3) بناء نسخة release موقّعة
cd android
./gradlew :app:assembleRelease
# الناتج: app/build/outputs/apk/release/app-release.apk

# أو بناء نسخة تجريبية للتصحيح
./gradlew :app:assembleDebug
```

## كلمات سر مفتاح التوقيع

| البند | القيمة |
|---|---|
| الملف | `keystore/plant-doctor.jks` |
| كلمة سر المخزن | `plantdoctor2026` |
| الاسم المستعار (alias) | `plantdoctor` |
| كلمة سر المفتاح | `plantdoctor2026` |

> ⚠️ **احتفظ بملف `.jks` في مكان آمن.** أي تحديث مستقبلي للتطبيق يجب أن يُوقّع بنفس المفتاح وإلا رفض أندرويد التحديث فوق النسخة المثبتة.

## لترقية نسخة جديدة

1. عدّل `www/index.html` (أو انسخ نسخة أحدث من التطبيق فوقه).
2. ارفع `versionCode` بمقدار 1 وحدّث `versionName` في `android/app/build.gradle`.
3. كرّر خطوات البناء أعلاه.

## مواضع تعديل مهمة

- اسم التطبيق: `android/app/src/main/res/values/strings.xml`
- الأذونات: `android/app/src/main/AndroidManifest.xml`
- الأيقونات: `android/app/src/main/res/mipmap-*/` (أُنتجت بـ `scripts/make_android_assets.py` في مستودع التطوير)

## مميزات النسخة v1.2

- تصنيف 6 حالات: سليمة، لفحة أوراق، لفحة مبكرة، صدأ، بياض دقيقي، اصفرار غذائي.
- تصوير مباشر من الكاميرا أو اختيار من المعرض (مع احترام دوران EXIF).
- **تصدير النتيجة كصورة PNG** (1080×1420) جاهزة للمشاركة عبر أي تطبيق.
- معالجة في Web Worker فلا تتجمد الواجهة، مع سقوط تلقائي للمسار المتزامن.
- يعمل **دون إنترنت تماماً**: كل المعالجة على الجهاز، صفر طلبات شبكة.
- سجل فحوصات (حتى 20 فحصاً) + مشاركة نصية + واجهة اختبار للمطورين `window.__leafTest`.
